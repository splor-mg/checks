# SPDX-FileCopyrightText: 2023-present Francisco Júnior <fjunior.alves.oliveira@gmail.com>
#
# SPDX-License-Identifier: MIT
