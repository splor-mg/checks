# checks-py

[![PyPI - Version](https://img.shields.io/pypi/v/checks-py.svg)](https://pypi.org/project/checks-py)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/checks-py.svg)](https://pypi.org/project/checks-py)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install checks-py
```

## License

`checks-py` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
